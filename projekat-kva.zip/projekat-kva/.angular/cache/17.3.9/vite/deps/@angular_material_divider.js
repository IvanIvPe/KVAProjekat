import {
  MatDivider,
  MatDividerModule
} from "./chunk-BEDLUDF5.js";
import "./chunk-KGJUWOUT.js";
import "./chunk-6AM2523Y.js";
import "./chunk-4MZAX6BM.js";
import "./chunk-FRPRYHQD.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
