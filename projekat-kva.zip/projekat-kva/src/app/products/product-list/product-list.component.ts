import { Component, OnInit } from '@angular/core';
import { Product, ProductService } from '../../services/product.service';
import { PageEvent } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
})
export class ProductListComponent implements OnInit {
  products!: Array<Product>;
  filteredProducts!: Array<Product>;
  selectedCategory: string = 'All';
  selectedSizes: Set<string> = new Set<string>();
  selectedPriceRange: [number, number] = [0, 250];
  searchTerm = '';

  totalProducts!: number;
  paginatedProducts!: Array<Product>;
  pageSize = 10;
  currentPage = 0;
  pageSizeOptions = [5, 10, 15, 30];
  showPageSizeOptions = true;

  ngOnInit(): void {
    this.products = this.productService.getAllProducts();
    this.filteredProducts = this.products;
    this.totalProducts = this.products.length;
    this.paginateProducts();
  }

  constructor(
    private productService: ProductService,
    private router: Router,
    private cartService: CartService
  ) {}

  // upravlja promenom stranice
  handlePageChange(event: PageEvent) {
    this.currentPage = event.pageIndex;
    this.pageSize = event.pageSize;
    this.paginateProducts();
  }

  // paginira niz proizvoda
  paginateProducts() {
    const startIndex = this.currentPage * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    this.paginatedProducts = this.filteredProducts.slice(startIndex, endIndex);
  }

  // filtrira proizvode na osnovu ulazne vrednosti pretrage
  doSearch(inputValue: string) {
    this.searchTerm = inputValue.trim().toLowerCase();

    if (this.searchTerm) {
      this.filterProducts();
    } else {
      this.filteredProducts = this.products;
    }

    this.totalProducts = this.filteredProducts.length;
    this.currentPage = 0;
    this.paginateProducts();
    this.filterProducts();
  }

  // filtrira proizvode prema odabranoj kategoriji
  filterByCategory() {
    this.filterProducts();
  }

  // filtrira proizvode prema odabranim velicinama
  filterBySize(size?: string) {
    if (size) {
      if (this.selectedSizes.has(size)) {
        this.selectedSizes.delete(size);
      } else {
        this.selectedSizes.add(size);
      }
    }

    this.filterProducts();
  }

  // filtrira proizvode prema odabranom rasponu cena
  filterByPrice() {
    this.filterProducts();
  }

  // kombinuje sve kriterijume filtera
  filterProducts() {
    this.filteredProducts = this.products.filter((product) => {
      const matchesSearchTerm =
        this.searchTerm === '' ||
        product.name.toLowerCase().includes(this.searchTerm);

      const matchesCategory =
        this.selectedCategory === 'All' ||
        product.category === this.selectedCategory;

      const matchesSize =
        this.selectedSizes.size === 0 || this.selectedSizes.has(product.size);

      const matchesPrice =
        product.price >= this.selectedPriceRange[0] &&
        product.price <= this.selectedPriceRange[1];

      return (
        matchesCategory && matchesSize && matchesPrice && matchesSearchTerm
      );
    });

    this.totalProducts = this.filteredProducts.length;
    this.currentPage = 0;
    this.paginateProducts();
  }

  // preusmerava na komponentu sa detaljima o proizvodu i prosledjuje id proizvoda na koji se klikne
  viewProductDetails(id: number) {
    this.router.navigate(['/product-list', id]);
  }

  // dodaje artikal u korpu
  addToCart(product: Product) {
    this.cartService.addToCart(product);
  }
}