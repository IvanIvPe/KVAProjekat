import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  address: string;
  city: string;
  zipCode: number;
  phoneNumber: string;
}

@Injectable()
export class UserService {
  static dummyUserList: Array<User> = [
    {
      id: 0,
      firstName: 'Ivan',
      lastName: 'Pesic',
      email: 'ivanpesic@gmail.com',
      password: 'ivanpesic',
      address: 'Nikole Pasica 100',
      city: 'Nis',
      zipCode: 18000,
      phoneNumber: '123456789',
    },
    {
      id: 1,
      firstName: 'test',
      lastName: 'user',
      email: 'testuser@gmail.com',
      password: 'testuser',
      address: 'Test Adresa',
      city: 'Beograd',
      zipCode: 11000,
      phoneNumber: '987654321',
    },
  ];

  currentUser?: User;

  // prati stanje trenutnih podataka korisnika
  private userSubject = new BehaviorSubject<User>(
    this.getUserFromLocalStorage()
  );
  userSubject$ = this.userSubject.asObservable();

  // prati stanje prijave korisnika
  private loginStatus = new BehaviorSubject<boolean>(this.isLoggedIn());
  isLoggedIn$ = this.loginStatus.asObservable();

  // vraca korisnika na osnovu datatog email-a
  getUserByEmail(email: string): User {
    this.currentUser = UserService.dummyUserList.find(
      (user) => user.email === email
    )!;

    return this.currentUser;
  }

  // preuzima korisnicke podatke iz lokalne memorije
  getUserFromLocalStorage() {
    return JSON.parse(localStorage.getItem('user')!);
  }

  // azurira korisnika
  updateUser(newUser: User) {
    UserService.dummyUserList.find((user) => {
      if (user.id === newUser.id) {
        user.firstName = newUser.firstName;
        user.lastName = newUser.lastName;
        user.email = newUser.email;
        user.password = newUser.password;
        user.address = newUser.address;
        user.city = newUser.city;
        user.zipCode = newUser.zipCode;
        user.phoneNumber = newUser.phoneNumber;
      }
    });
    localStorage.setItem('user', JSON.stringify(newUser));
    this.userSubject.next(newUser);
  }

  // proverava da li je navedena lozinka validna
  isPasswordValid(email: string, password: string): boolean {
    return (
      UserService.dummyUserList.find(
        (user) => user.email === email && user.password === password
      ) !== undefined
    );
  }

  // registruje novog korisnika
  registerUser(
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    address: string,
    city: string,
    zipCode: number,
    phoneNumber: string
  ): User {
    let maxId: number = 0;

    UserService.dummyUserList.forEach((user) => {
      if (maxId < user.id) {
        maxId = user.id;
      }
    });

    let id = ++maxId;
    let user: User = {
      id,
      firstName,
      lastName,
      email,
      password,
      address,
      city,
      zipCode,
      phoneNumber,
    };

    UserService.dummyUserList.push(user);

    this.currentUser = user;

    return user;
  }

  // prijavljuje korisnika
  login(user: User) {
    localStorage.setItem('user', JSON.stringify(user));
    this.currentUser = user;
    this.userSubject.next(user);
    this.loginStatus.next(true);
  }

  // proverava da li je korisnik prijavljen
  isLoggedIn() {
    return !!localStorage.getItem('user');
  }

  // odjavljuje korisnika
  logout() {
    localStorage.removeItem('user');
    this.loginStatus.next(false);
  }
}