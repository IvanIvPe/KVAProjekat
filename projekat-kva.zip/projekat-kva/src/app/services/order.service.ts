import { Injectable } from '@angular/core';
import { Product } from './product.service';
import { UserService } from './user.service';

export interface Order {
  id: number;
  createdAt: Date;
  orderedProducts: Array<Product>;
  totalPrice: number;
  userId: number;
}

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  private static dummyOrderList: Array<Order> = [];

  maxId: number = 0;

  constructor(private userService: UserService) {}

  // vraca sve porudzbine
  getAllOrders() {
    return OrderService.dummyOrderList;
  }

  // vraca sve porudzbine koje se podudaraju sa navedenim ID-om korisnika
  getOrdersByUserId(userId: number) {
    userId = this.userService.getUserFromLocalStorage().id;

    let orders: Array<Order> = OrderService.dummyOrderList.filter(
      (order) => order.userId === userId
    );

    return orders;
  }

  // kreira order i gura ga u niz dummyOrderList
  createOrder(cartItems: Product[]) {
    let price = cartItems.reduce((price, item) => {
      return price + item.price * item.quantity;
    }, 0);

    let userId = this.userService.getUserFromLocalStorage().id;

    let order = {
      id: ++this.maxId,
      createdAt: new Date(),
      orderedProducts: cartItems,
      totalPrice: price,
      userId: userId,
    };

    OrderService.dummyOrderList.push(order);
  }
}