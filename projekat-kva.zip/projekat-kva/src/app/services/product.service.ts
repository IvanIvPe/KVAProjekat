import { Injectable } from '@angular/core';

export interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  description: string;
  manufacturer: string;
  category: 'T-shirt' | 'Shoes' | 'Shorts' | 'Accessories' ;
  size: 'S' | 'M' | 'L' | 'XL' | '39' | '40' | '41' | '42' | '43' | 'One Size' ;
  quantity: number;
  addedDate: Date
}

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  static dummyProductList: Array<Product> = [
    {
      id: 0,
      name: 'Adidas Ultraboost 21',
      price: 180,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/c1eb190cf35440038645ad4f0105e2e7_9366/Ultraboost_21_Running_Shoes_Black_GX5236_01_standard.jpg',
      description: 'High-performance running shoes with a responsive Boost midsole.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '42',
      addedDate: new Date('2024-06-12T08:00:00'),
      quantity: 0
      
    },
    {
      id: 1,
      name: 'Adidas Originals Superstar',
      price: 85,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/d0e4f46883814db9999bb20f0c9c9df0_9366/Superstar_Shoes_Black_JH9159_01_standard.jpg',
      description: 'Classic Adidas Superstar shoes with the iconic shell toe.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '41',
      addedDate: new Date('2024-06-12T08:00:00'),
      quantity: 0
    },
    {
      id: 2,
      name: 'Adidas Tiro 21 Training Pants',
      price: 45,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/b1c2e2e1bca64453b226071c8a2bc031_9366/Tiro_24_Training_Pants_Black_IP1952_25_model.jpg',
      description: 'Comfortable training pants with moisture-absorbing AEROREADY.',
      category: 'Shorts',
      manufacturer: 'Adidas',
      size: 'L',
      addedDate: new Date('2024-06-11T09:00:00'),
      quantity: 0
    },
    {
      id: 3,
      name: 'Adidas NMD_R1',
      price: 140,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/6c08ef21f0c247fb8ae62cd3eb9a391b_9366/NMD_R1_Shoes_Red_ID9147_01_standard.jpg',
      description: 'Street-ready sneakers with Boost cushioning for all-day comfort.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '43',
      addedDate: new Date('2024-06-15T10:00:00'),
      quantity: 0
    },
    {
      id: 4,
      name: 'Adidas 3-Stripes T-Shirt',
      price: 30,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/bf9d73fb98c34984a08caf150099dfe0_9366/Adicolor_Classics_3-Stripes_Tee_Black_IA4845_01_laydown.jpg',
      description: 'Classic Adidas T-shirt with 3-Stripes detailing on the sleeves.',
      category: 'T-shirt',
      manufacturer: 'Adidas',
      size: 'M',
      addedDate: new Date('2024-06-10T08:00:00'),
      quantity: 0
    },
    {
      id: 5,
      name: 'Adidas Adilette Slides',
      price: 25,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/735919589b6d4d84bb66ad6e00cb68ba_9366/Adilette_Comfort_Slides_Black_GZ5891_01_standard.jpg',
      description: 'Comfortable slides for everyday wear with a quick-dry lining.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '42',
      addedDate: new Date('2024-06-11T09:00:00'),
      quantity: 0
    },
    {
      id: 6,
      name: 'Adidas Essentials Hoodie',
      price: 55,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/4700321582704a418b13aca8009b9a9d_9366/Essentials_French_Terry_3-Stripes_Full-Zip_Hoodie_Black_GK9032_01_laydown.jpg',
      description: 'Fleece hoodie for cozy comfort and casual style.',
      category: 'T-shirt',
      manufacturer: 'Adidas',
      size: 'XL',
      addedDate: new Date('2024-06-09T08:00:00'),
      quantity: 0
    },
    {
      id: 7,
      name: 'Adidas Predator Freak.3',
      price: 80,
      image: 'https://www.sportvision.rs/files/watermark/files/images/slike_proizvoda/media/FY6/FY6295/images/thumbs_w/FY6295_w_800_800px.jpg',
      description: 'Firm ground soccer boots with a textured surface for better ball control.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '40',
      addedDate: new Date('2024-06-12T08:00:00'),
      quantity: 0
    },
    {
      id: 8,
      name: 'Adidas Trefoil Crew Socks',
      price: 15,
      image: 'https://m.media-amazon.com/images/I/71hED83tTlL._AC_SX569_.jpg',
      description: 'Soft and stretchy crew socks with iconic Trefoil branding.',
      category: 'Accessories',
      manufacturer: 'Adidas',
      size: 'L',
      addedDate: new Date('2024-06-06T08:00:00'),
      quantity: 0
    },
    {
      id: 9,
      name: 'Adidas Forum Low',
      price: 90,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/09c5ea6df1bd4be6baaaac5e003e7047_9366/Forum_Low_Shoes_White_FY7756_01_standard.jpg',
      description: 'Retro-inspired sneakers with a low-top design and adjustable strap.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '41',
      addedDate: new Date('2024-06-11T08:00:00'),
      quantity: 0
    },
    {
      id: 10,
      name: 'Adidas Essentials 3-Stripes Shorts',
      price: 35,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/d55a2574d7c14d5383c4af020121e9cc_9366/AEROREADY_Essentials_Chelsea_3-Stripes_Shorts_Black_IC1484_21_model.jpg',
      description: 'Lightweight shorts with 3-Stripes detailing for casual wear.',
      category: 'Shorts',
      manufacturer: 'Adidas',
      size: 'M',
      addedDate: new Date('2024-06-07T08:00:00'),
      quantity: 0
    },
    {
      id: 11,
      name: 'Adidas EQT Support 93/17',
      price: 160,
      image: 'https://cdn-images.farfetch-contents.com/11/91/44/35/11914435_9011492_1000.jpg',
      description: 'Innovative sneakers with Boost cushioning and a snug fit.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '42',
      addedDate: new Date('2024-06-12T08:00:00'),
      quantity: 0
    },
    {
      id: 12,
      name: 'Adidas ID Stadium Full-Zip Hoodie',
      price: 65,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/2853b38f1800477b8966aeea013fc9d3_9366/Stadium_Full-Zip_Hoodie_Black_HN9636_01_laydown.jpg',
      description: 'Full-zip hoodie with a soft cotton-blend fabric for all-day comfort.',
      category: 'T-shirt',
      manufacturer: 'Adidas',
      size: 'L',
      addedDate: new Date('2024-06-07T08:00:00'),
      quantity: 0
    },
    {
      id: 13,
      name: 'Adidas Solarboost 3',
      price: 120,
      image: 'https://www.intersport.rs/media/catalog/product/cache/5864b084779f11fa289096d3dce89f9c//f/w/fw9139_ftw_photo_side-lateral-center_white.jpg',
      description: 'Running shoes with responsive cushioning for long-distance comfort.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '43',
      addedDate: new Date('2024-06-09T08:00:00'),
      quantity: 0
    },
    {
      id: 14,
      name: 'Adidas Must Haves Badge of Sport T-Shirt',
      price: 25,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/5a385a6ef1ea45fb86a8abba00fc0a65_9366/Must_Haves_Badge_of_Sport_Tee_Green_GC6962_01_laydown.jpg',
      description: 'Soft cotton T-shirt with the Adidas Badge of Sport on the chest.',
      category: 'T-shirt',
      manufacturer: 'Adidas',
      size: 'M',
      addedDate: new Date('2024-06-06T08:00:00'),
      quantity: 0
    },
    {
      id: 15,
      name: 'Adidas Ultraboost DNA',
      price: 180,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/c608f554cb3b4d12b392af000188c513_9366/ULTRABOOST_1.0_SHOES_Black_HQ4199_01_00_standard.jpg',
      description: 'Stylish sneakers with a responsive Boost midsole for all-day comfort.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '42',
      addedDate: new Date('2024-06-11T08:00:00'),
      quantity: 0
    },
    {
      id: 16,
      name: 'Adidas Z.N.E. 01 True Wireless Earbuds',
      price: 140,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/a7d71f8327564725833badcc00f9866e_9366/adidas_Z.N.E._01_True_Wireless_Earbuds_Grey_EY5116_03_standard_hover.jpg',
      description: 'Wireless earbuds with a sleek design and superior sound quality.',
      category: 'Accessories',
      manufacturer: 'Adidas',
      size: 'One Size',
      addedDate: new Date('2024-06-08T08:00:00'),
      quantity: 0
    },
    {
      id: 17,
      name: 'Adidas Continental 80',
      price: 100,
      image: 'https://www.nselection.rs/UserFiles/products/big/02/21/muske-patike-adidas-continental-80-G27706.png',
      description: 'Retro sneakers with a classic design and split rubber cupsole.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '42',
      addedDate: new Date('2024-06-09T08:00:00'),
      quantity: 0
    },
    {
      id: 18,
      name: 'Adidas Pro Model',
      price: 95,
      image: 'https://m.media-amazon.com/images/I/81Kvd5EFBsL._AC_SX575_.jpg',
      description: 'High-top sneakers with the iconic shell toe and leather upper.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '41',
      addedDate: new Date('2024-06-11T08:00:00'),
      quantity: 0
    },
    {
      id: 19,
      name: 'Adidas Tiro Duffel Bag',
      price: 40,
      image: 'https://assets.adidas.com/images/w_766,h_766,f_auto,q_auto,fl_lossy,c_fill,g_auto/b4fa9405b5554d2ca531af4c010a857b_9366/tiro-league-duffel-bag-small.jpg',
      description: 'Spacious duffel bag with multiple compartments for organized storage.',
      category: 'Accessories',
      manufacturer: 'Adidas',
      size: 'One Size',
      addedDate: new Date('2024-06-10T08:00:00'),
      quantity: 0
    },
    {
      id: 20,
      name: 'Adidas Stan Smith',
      price: 90,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/516b139c9f3b44a0b5cae45c7764e40a_9366/Stan_Smith_Shoes_Black_ID1341_01_standard.jpg',
      description: 'Iconic Stan Smith sneakers with a minimalist design and leather upper.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '39',
      addedDate: new Date('2024-06-11T08:00:00'),
      quantity: 0
    },
    {
      id: 21,
      name: 'Adidas Badge of Sport Cap',
      price: 22,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/7cdc55fbc9804c3d9b9dac08002c699d_9366/Badge_of_Sport_Logo_Snapback_Hat_White_EW9716_01_standard.jpg',
      description: 'Classic cap with an adjustable strap and the Adidas Badge of Sport logo.',
      category: 'Accessories',
      manufacturer: 'Adidas',
      size: 'One Size',
      addedDate: new Date('2024-06-06T08:00:00'),
      quantity: 0
    },
    {
      id: 22,
      name: 'Adidas Adizero Boston 9',
      price: 110,
      image: 'https://www.sportvision.rs/files/thumbs/files/images/slike_proizvoda/media/FY0/FY0343/images/thumbs_600/FY0343_600_600px.jpg',
      description: 'Lightweight running shoes designed for speed and long-distance runs.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '42',
      addedDate: new Date('2024-06-08T08:00:00'),
      quantity: 0
    },
    {
      id: 23,
      name: 'Adidas Essentials Fleece Joggers',
      price: 45,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/a8de353366394787bb83aefd00e5e262_9366/Essentials_Fleece_Joggers_Black_IA6437_01_laydown.jpg',
      description: 'Cozy fleece joggers with a tapered fit and elastic waistband.',
      category: 'Shorts',
      manufacturer: 'Adidas',
      size: 'M',
      addedDate: new Date('2024-06-09T08:00:00'),
      quantity: 0
    },
    {
      id: 24,
      name: 'Adidas Terrex Swift R2 GTX',
      price: 140,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/46e340802ae249cc9280a9ae010e71bb_9366/TERREX_Swift_R2_GORE-TEX_Hiking_Shoes_Grey_BC0383_01_standard.jpg',
      description: 'Rugged hiking shoes with GORE-TEX® lining for waterproof performance.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '43',
      addedDate: new Date('2024-06-12T08:00:00'),
      quantity: 0
    },
    {
      id: 25,
      name: 'Adidas Nite Jogger',
      price: 130,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/569aad5a69824441bf11ac1c00aaf0e9_9366/Ninja_Nite_Jogger_Shoes_Orange_Q47199_01_standard.jpg',
      description: 'Reflective sneakers with Boost cushioning and a retro-inspired design.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '42',
      addedDate: new Date('2024-06-09T08:00:00'),
      quantity: 0
    },
    {
      id: 26,
      name: 'Adidas 3-Stripes Duffel Bag',
      price: 38,
      image: 'https://assets.adidas.com/images/w_1880,f_auto,q_auto/43ac0d6500354bf49252996d174d0ad7_9366/IP9862_01_standard.jpg',
      description: 'Durable duffel bag with a roomy interior and multiple carry options.',
      category: 'Accessories',
      manufacturer: 'Adidas',
      size: 'One Size',
      addedDate: new Date('2024-06-10T08:00:00'),
      quantity: 0
    },
    {
      id: 27,
      name: 'Adidas Gazelle',
      price: 85,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/a8d93c94c96946ef9c6728479b08613a_9366/Gazelle_Shoes_Brown_IF9802_01_standard.jpg',
      description: 'Classic Gazelle sneakers with a suede upper and versatile design.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '40',
      addedDate: new Date('2024-06-08T08:00:00'),
      quantity: 0
    },
    {
      id: 28,
      name: 'Samba OG Shoes',
      price: 100,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/f373094a5e1a48c4826431bfb8253593_9366/Samba_OG_Shoes_Blue_ID1454_01_standard.jpg',
      description: 'Rock iconic soccer-inspired style all year long in these adidas Samba OG shoes.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '43',
      addedDate: new Date('2024-07-08T08:00:00'),
      quantity: 0
    },
    {
      id: 29,
      name: 'Campus 00s Shoes',
      price: 110,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/1b310c445a17412b84f6a2e5b7f8e66f_9366/Campus_00s_Shoes_Brown_IF8770_01_standard.jpg',
      description: 'An iconic 80s design reimagined for today, these adidas shoes take shape with a smooth leather upper, suede accents and a rubber outsole thats familiar yet fresh.',
      category: 'Shoes',
      manufacturer: 'Adidas',
      size: '40',
      addedDate: new Date('2024-07-08T08:00:00'),
      quantity: 0
    },
    {
      id: 30,
      name: 'Adicolor 3-Stripes Swim Shorts',
      price: 55,
      image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/9ba23594104748159e30af0900bb2b34_9366/Adicolor_3-Stripes_Swim_Shorts_Black_HT4419_21_model.jpg',
      description: 'From beach vacations to pool parties, these adidas swim shorts set you up for warm-weather fun.',
      category: 'Shorts',
      manufacturer: 'Adidas',
      size: 'S',
      addedDate: new Date('2024-07-08T08:10:00'),
      quantity: 0
    }
  ];

  // vraca sve proizvode
  getAllProducts() {
    return ProductService.dummyProductList;
  }

  // vraca proizvod na osnovu navedenog ID-a
  getProductById(id: number): Product {
    let foundProduct!: Product;

    ProductService.dummyProductList.find((product) => {
      if (product.id === id) {
        foundProduct = product;
      }
    });

    return foundProduct;
  }
}